package com.mvc2;

public class Data {

}
